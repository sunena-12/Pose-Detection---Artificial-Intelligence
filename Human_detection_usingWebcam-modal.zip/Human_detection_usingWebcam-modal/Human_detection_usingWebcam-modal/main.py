import cv2
from djitellopy import tello
import cvzone
import pygame
import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import datetime

# Initialize pygame mixer
pygame.mixer.init()

thres = 0.6
nmsThres = 0.2
cap = cv2.VideoCapture(0)
cap.set(3, 640)
cap.set(4, 480)

# Import all classes
classNames = []
classFile = 'coco.names'
with open(classFile, 'rt') as f:
    classNames = f.read().split('\n')
print(classNames)

# get configfile and weights
configPath = 'ssd_mobilenet_v3_large_coco_2020_01_14.pbtxt'
weightsPath = 'frozen_inference_graph.pb'

# Load in network
net = cv2.dnn_DetectionModel(weightsPath, configPath)
net.setInputSize(320, 320)
net.setInputScale(1.0/127.5)
net.setInputMean((127.5, 127.5, 127.5))
net.setInputSwapRB(True)

# Load the alarm sound
alarm_sound = pygame.mixer.Sound("alert.wav")

# Create a directory to save captured photos and videos
if not os.path.exists("captured_media"):
    os.mkdir("captured_media")

media_counter = 0
max_photos_per_person = 4  # Set the desired number of photos per person

person_id_counter = {}  # Keep track of the number of photos per person

recording = False
record_start_frame = None
record_duration = 0

video_writer = None

def sendThroughEmail():
    fromaddr = "maheshwarisunena@gmail.com"
    toaddr = "cs1912170@szabist.pk"
    
    msg = MIMEMultipart()
    
    msg['From'] = fromaddr
    msg['To'] = toaddr
    msg['Subject'] = "ABNORMAL SITUATION"
    
    body = "Person detected!"
    msg.attach(MIMEText(body, 'plain'))
    
    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.starttls()
    server.login(fromaddr, "wuefprzvrcowxpbr")
    text = msg.as_string()
    server.sendmail(fromaddr, toaddr, text)
    server.quit()

while True:
    
    success, img = cap.read()
    classIds, confs, bbox = net.detect(img, confThreshold=thres, nmsThreshold=nmsThres)

    try:
        for classId, conf, box in zip(classIds.flatten(), confs.flatten(), bbox):
            cvzone.cornerRect(img, box)
            # Add text indicating which class has been detected
            cv2.putText(img, f'{classNames[classId-1].upper()} {round(conf*100, 2)}',
                        (box[0] + 10, box[1] + 30), cv2.FONT_HERSHEY_COMPLEX, 1, (0, 255, 0), 2)

            # Check if a human is detected (you may need to adjust the classId for humans)
            if classNames[classId - 1].lower() == "person":
                # Get a unique identifier for each person (use the box coordinates as an identifier)
                person_identifier = tuple(box)

                # Check if the person identifier is already in the counter
                if person_identifier not in person_id_counter:
                    person_id_counter[person_identifier] = 0

                # Check if we can capture more photos for this person
                if person_id_counter[person_identifier] < max_photos_per_person:
                    person_id_counter[person_identifier] += 1
                    media_counter += 1
                    photo_filename = f"captured_media/human_{media_counter}.jpg"
                    cv2.imwrite(photo_filename, img)

                    # Play the alarm sound when a human is detected
                    alarm_sound.play()

                # Start video recording for this person
                if not recording:
                    recording = True
                    record_start_frame = img
                    record_duration = 0
                    video_filename = f"captured_media/human_{media_counter}.avi"
                    frame_height, frame_width, _ = img.shape
                    fourcc = cv2.VideoWriter_fourcc(*'XVID')
                    video_writer = cv2.VideoWriter(video_filename, fourcc, 20.0, (frame_width, frame_height))

                # Send an email alert
                sendThroughEmail()

            # Stop video recording after 5-10 seconds
            if recording:
                record_duration += 1
                video_writer.write(img)
                if record_duration >= 5 * 20:  # Adjust as needed (5 seconds at 20 FPS)
                    recording = False
                    video_writer.release()

    except:
        pass

    cv2.imshow("Image", img)
    cv2.waitKey(1)
